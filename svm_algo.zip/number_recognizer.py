


import pandas as pd
import sklearn
import numpy
import scipy
import statsmodels
import math
import matplotlib as matlab
import matplotlib.pyplot as plt
import PIL
from sklearn import svm
import numpy
from sklearn.metrics import confusion_matrix




####LAB: Digit Recognition Using SVM
################################################
###SVM for Hand Written Digit Recognition Example

###Take an image of a handwritten single digit, and determine what that digit is.
#Importing test and training data

train_data = numpy.loadtxt('zip.train.txt')
test_data  = numpy.loadtxt('zip.test.txt')

train_data.shape
test_data.shape

#Normalized handwritten digits, automatically scanned from envelopes by the U.S.
#Postal Service. The original scanned digits are binary and of different sizes and orientations; 
#the images  here have been de slanted and size normalized,
#resultingin 16 x 16 grayscale images (Le Cun et al., 1990).

#Lets see some images. 

data_row=train_data[0][1:]
#pixels = matrix(as.numeric(data_row),16,16,byrow=TRUE)
pixels = numpy.matrix(data_row)
pixels=pixels.reshape(16,16)
plt.imshow(pixels)


data_row=train_data[1][1:]
#pixels = matrix(as.numeric(data_row),16,16,byrow=TRUE)
pixels = numpy.matrix(data_row)
pixels=pixels.reshape(16,16)
plt.imshow(pixels)


data_row=train_data[2][1:]
#pixels = matrix(as.numeric(data_row),16,16,byrow=TRUE)
pixels = numpy.matrix(data_row)
pixels=pixels.reshape(16,16)
plt.imshow(pixels)


data_row=train_data[5][1:]
#pixels = matrix(as.numeric(data_row),16,16,byrow=TRUE)
pixels = numpy.matrix(data_row)
pixels=pixels.reshape(16,16)
plt.imshow(pixels)

data_row=train_data[500][1:]
#pixels = matrix(as.numeric(data_row),16,16,byrow=TRUE)
pixels = numpy.matrix(data_row)
pixels=pixels.reshape(16,16)
plt.imshow(pixels)




  #print(plt.imshow(pixels))
  # help(matlab.image) 
  #  title(main = paste("Label is" , train_data[i,1]), font.main = 4)
  #help(numpy.matrix)
  #numpy.matrix(data_row)
  
  #Are there any missing values?
sum(sum(pd.isnull(train_data))) 
sum(sum(pd.isnull(test_data))) 

#The data are in two gzipped files, and each line consists of the digitid (0-9) followed by the 256 grayscale values. 	
#The first variable is label
train_data1= pd.DataFrame(train_data)
train_data1[0].value_counts()       
 
test_data1= pd.DataFrame(test_data)
test_data1[0].value_counts()


#Build an SVM model that can be used as the digit recognizer 
########SVM Model Building 
#Verify the code with small data
X1=train_data[:5000,range(1,257)]
Y1 =train_data[0:5000,0]
import time
start_time = time.time()
numbersvm = svm.SVC(kernel='rbf', C=1).fit(X1,Y1)
print("--- %s seconds ---" % (time.time() - start_time)) 
# Expected run time = 2.14 secs


#Confusion Matrix
predict6 = numbersvm.predict(X1)
predict6
conf_mat = confusion_matrix(Y1,predict6)
conf_mat
Y1 = pd.DataFrame(Y1)
Y1[0].value_counts()

predict6=pd.DataFrame(predict6)
predict6[0].value_counts() 

###################################
#####Model on Full Data 
X2=train_data[:,range(1,257)]
Y2 =train_data[:,0]
import time
start_time = time.time()
numbersvm = svm.SVC(kernel='rbf', C=1).fit(X2,Y2)
print("--- %s seconds ---" % (time.time() - start_time)) 

#Confusion Matrix
predict7 = numbersvm.predict(X2)
conf_mat = confusion_matrix(Y2,predict7)
conf_mat
from sklearn.metrics import accuracy_score
accuracy_score(Y2,predict7)

###Out of time validation with test data
Ex1 = test_data[:,range(1,257)]
Ey1 = test_data[:,0]
test_predict = numbersvm.predict(Ex1)
conf_mat = confusion_matrix(Ey1,test_predict)
conf_mat


from sklearn.metrics import accuracy_score
acc_digits=accuracy_score(Ey1,test_predict)
print(acc_digits)

 

        
