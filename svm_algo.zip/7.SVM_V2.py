
import pandas as pd
import sklearn
import numpy
import scipy
import statsmodels
import math
import matplotlib as matlab
import matplotlib.pyplot as plt
import PIL
from sklearn import svm
import numpy


#### LAB: Kernel Non-Linear Classifier
######################################
###### Kernels
#Dataset : Software users/sw_user_profile.csv  
sw_user_profile = pd.read_csv("sw_user_profile.csv")
#How many variables are there in software user profile data?
sw_user_profile.shape
# 3 Variables
#Plot the active users against and check weather the relation between age and "Active" status is linear or non-linear
plt.scatter(sw_user_profile.Age,sw_user_profile.Id, c=sw_user_profile[['Active']].values.ravel())



########################################
## model1
######################################

#Build an SVM model(model-1), make sure that there is no kernel or the kernel is linear

#Model Building 
#Build an SVM model(model-1), make sure that there is no kernel or the kernel is linear

#Model Building 
X= sw_user_profile[['Age']]
y= sw_user_profile[['Active']].values.ravel()
Linsvc = svm.SVC(kernel='linear', C=1).fit(X, y)
predict3 = Linsvc.predict(X)
#For model-1, create the confusion matrix and find out the accuracy
#Confusion Matrix
from sklearn.metrics import confusion_matrix
conf_mat = confusion_matrix(sw_user_profile[['Active']],predict3)
conf_mat

#Accuracy 
Accuracy3 = Linsvc.score(X, y)
Accuracy3




########################################
## model2
######################################

#######################################
#New variable derivation. Mapping to higher dimensions

#Standardizing the data to visualize the results clearly
sw_user_profile['age_nor']=(sw_user_profile.Age-numpy.mean(sw_user_profile.Age))/numpy.std(sw_user_profile.Age) 
#Create a new variable. By using the polynomial kernel
#Creating the new variable
sw_user_profile['new']=(sw_user_profile.age_nor)*(sw_user_profile.age_nor)


#Build an SVM model(model-2), with the new data mapped on to higher dimensions. Keep the default kernel in R as linear
#Model Building with new variable
X= sw_user_profile[['Age']+['new']]
y= sw_user_profile[['Active']].values.ravel()
Linsvc = svm.SVC(kernel='linear', C=1).fit(X, y)
predict4 = Linsvc.predict(X)
#For model-2, create the confusion matrix and find out the accuracy
#Confusion Matrix
conf_mat = confusion_matrix(sw_user_profile[['Active']],predict4)
conf_mat

#Accuracy 
Accuracy4 = Linsvc.score(X, y)
Accuracy4


########################################
## model3
######################################
#With the original data re-cerate the model(model-3) and let python choose the default kernel function. 
########Model Building with radial kernel function
X= sw_user_profile[['Age']]
y= sw_user_profile[['Active']].values.ravel()
Linsvc = svm.SVC(kernel='rbf', C=1).fit(X, y)
predict5 = Linsvc.predict(X)
conf_mat = confusion_matrix(sw_user_profile[['Active']],predict5)
conf_mat

#Accuracy model-3
Accuracy5 = Linsvc.score(X, y)
Accuracy5







